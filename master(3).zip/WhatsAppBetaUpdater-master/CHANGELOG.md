### 3.1.3
**Released: 30 January, 2016**
* Minor design tweaks.
* Fixed some crashes.

***

### 3.1.2
**Released: 27 January, 2016**
* Bug fixes.
* Italian, Turkish and French translations.

***

### 3.1.1 / 3.1
**Released: 25 January, 2016**
* Added button to cancel the download.
* Added customizable notification sound.
* Added "1 hour" on notification frequency.
* Option to share downloaded update on Telegram, email, etc.
* Shows message when the download fails.
* Improved donation dialog.
* Fixed some issues on Android 4.x
* Japenese, German, Catalan and Dutch translations.

***

### 3.0
**Released: 16 January, 2016**
* Rewritten from zero with new UI, faster loading time and bug fixes.

***

### 2.2
**Released: 3 May, 2015**
* In-App Updater.
* Notifications frequency is available in Settings.
* [OFFICIAL ANNOUNCEMENT](https://plus.google.com/+JavierSantos/posts/S1bNZARRPi7) Say goodbye to the ads!

***

### 2.1
**Released: 29 April, 2015**
* Added cancel button to download dialog.
* Frech, Italian, Portuguese, Turkish and Japanese languages.

***

### 2.0
**Released: 22 April, 2015**
* Notifications.
* FAB (Material Design).
* Dialog to delete APK.
* Ads are now displayed faster.
* "Rate on Google Play" and "Join the community" added to Settings.
* Catalan translation (by Marc C) and Japanese translation.

***

### 1.1
**Released: 15 April, 2015**
* Settings: autodownload when a new version is available.
* Screen when WiFi/3G is disabled.
* Download directory now use the default 'DirectoryDownloads' of Android.
* * Remove landscape orientation.
* Added German translation.

***

### 1.0.0.4 / 1.0.0.3
**Released: 5 April, 2015**
* Better method to compare versions.

***

### 1.0.0.2
**Released: 5 April, 2015**
* Added "Check for updates" button.
* Rename "WhatsApp Beta Updater" to "Beta Updater for WhatsApp".

package com.javiersantos.whatsappbetaupdater.util;

public class UtilsEnum {

    public enum DownloadType { WHATSAPP_APK, UPDATE }

}
